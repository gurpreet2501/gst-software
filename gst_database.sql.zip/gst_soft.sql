-- phpMyAdmin SQL Dump
-- version 4.8.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 12, 2018 at 03:36 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gst_soft`
--

-- --------------------------------------------------------

--
-- Table structure for table `bill_gst`
--

CREATE TABLE `bill_gst` (
  `id` int(10) UNSIGNED NOT NULL,
  `bill_id` int(11) NOT NULL,
  `gst_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `bill_gst`
--

INSERT INTO `bill_gst` (`id`, `bill_id`, `gst_id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '2017-07-18 14:17:07', '2017-07-18 14:17:07'),
(2, 1, 2, '2017-07-18 14:17:07', '2017-07-18 14:17:07'),
(3, 2, 4, '2017-07-18 14:28:20', '2017-07-18 14:28:20'),
(4, 3, 1, '2017-07-18 14:40:09', '2017-07-18 14:40:09'),
(5, 3, 4, '2017-07-18 14:40:09', '2017-07-18 14:40:09'),
(6, 4, 1, '2017-07-18 14:53:46', '2017-07-18 14:53:46'),
(7, 4, 2, '2017-07-18 14:53:47', '2017-07-18 14:53:47'),
(8, 4, 4, '2017-07-18 14:53:47', '2017-07-18 14:53:47'),
(9, 5, 1, '2017-07-18 15:17:43', '2017-07-18 15:17:43'),
(10, 5, 2, '2017-07-18 15:17:43', '2017-07-18 15:17:43'),
(11, 6, 1, '2017-07-18 15:22:08', '2017-07-18 15:22:08'),
(12, 6, 2, '2017-07-18 15:22:08', '2017-07-18 15:22:08'),
(13, 6, 4, '2017-07-18 15:22:08', '2017-07-18 15:22:08'),
(14, 7, 1, '2017-07-18 15:33:57', '2017-07-18 15:33:57'),
(15, 7, 2, '2017-07-18 15:33:57', '2017-07-18 15:33:57'),
(16, 7, 4, '2017-07-18 15:33:57', '2017-07-18 15:33:57'),
(17, 8, 1, '2017-07-18 18:31:07', '2017-07-18 18:31:07'),
(18, 8, 2, '2017-07-18 18:31:07', '2017-07-18 18:31:07'),
(19, 8, 3, '2017-07-18 18:31:07', '2017-07-18 18:31:07'),
(20, 8, 4, '2017-07-18 18:31:07', '2017-07-18 18:31:07'),
(21, 9, 1, '2017-07-18 18:34:55', '2017-07-18 18:34:55'),
(22, 9, 2, '2017-07-18 18:34:55', '2017-07-18 18:34:55'),
(23, 10, 1, '2017-07-18 18:36:30', '2017-07-18 18:36:30'),
(24, 10, 2, '2017-07-18 18:36:30', '2017-07-18 18:36:30'),
(25, 10, 1, '2017-09-15 19:31:19', '2017-09-15 19:31:19'),
(26, 10, 2, '2017-09-15 19:31:19', '2017-09-15 19:31:19'),
(27, 10, 4, '2017-09-15 19:31:19', '2017-09-15 19:31:19'),
(28, 11, 2, '2018-04-03 18:35:30', '2018-04-03 18:35:30'),
(29, 11, 4, '2018-04-03 18:35:30', '2018-04-03 18:35:30'),
(30, 12, 1, '2018-05-17 20:58:55', '2018-05-17 20:58:55'),
(31, 12, 4, '2018-05-17 20:58:55', '2018-05-17 20:58:55'),
(32, 13, 1, '2018-06-10 11:16:41', '2018-06-10 11:16:41'),
(33, 13, 2, '2018-06-10 11:16:41', '2018-06-10 11:16:41'),
(34, 16, 1, '2018-06-12 18:45:33', '2018-06-12 18:45:33'),
(35, 17, 1, '2018-06-12 18:48:13', '2018-06-12 18:48:13'),
(36, 17, 2, '2018-06-12 18:48:13', '2018-06-12 18:48:13'),
(37, 18, 1, '2018-06-12 18:48:21', '2018-06-12 18:48:21'),
(38, 18, 2, '2018-06-12 18:48:21', '2018-06-12 18:48:21'),
(39, 19, 1, '2018-06-12 18:50:27', '2018-06-12 18:50:27'),
(40, 19, 2, '2018-06-12 18:50:27', '2018-06-12 18:50:27'),
(41, 20, 1, '2018-06-12 18:51:26', '2018-06-12 18:51:26'),
(42, 20, 2, '2018-06-12 18:51:26', '2018-06-12 18:51:26'),
(43, 21, 1, '2018-06-12 18:54:20', '2018-06-12 18:54:20'),
(44, 21, 4, '2018-06-12 18:54:20', '2018-06-12 18:54:20'),
(45, 24, 1, '2018-06-12 18:57:36', '2018-06-12 18:57:36'),
(46, 25, 1, '2018-06-12 18:58:00', '2018-06-12 18:58:00'),
(47, 26, 1, '2018-06-12 19:00:20', '2018-06-12 19:00:20'),
(48, 26, 3, '2018-06-12 19:00:20', '2018-06-12 19:00:20'),
(49, 27, 1, '2018-06-12 19:02:23', '2018-06-12 19:02:23'),
(50, 27, 3, '2018-06-12 19:02:23', '2018-06-12 19:02:23'),
(51, 28, 1, '2018-06-12 19:02:36', '2018-06-12 19:02:36'),
(52, 28, 3, '2018-06-12 19:02:36', '2018-06-12 19:02:36'),
(53, 29, 1, '2018-06-12 19:02:46', '2018-06-12 19:02:46'),
(54, 29, 3, '2018-06-12 19:02:46', '2018-06-12 19:02:46'),
(55, 30, 1, '2018-06-12 19:02:53', '2018-06-12 19:02:53'),
(56, 30, 3, '2018-06-12 19:02:53', '2018-06-12 19:02:53'),
(57, 31, 1, '2018-06-12 19:03:09', '2018-06-12 19:03:09'),
(58, 31, 3, '2018-06-12 19:03:09', '2018-06-12 19:03:09'),
(59, 32, 1, '2018-06-12 19:03:58', '2018-06-12 19:03:58'),
(60, 32, 3, '2018-06-12 19:03:58', '2018-06-12 19:03:58'),
(61, 33, 1, '2018-06-12 19:04:10', '2018-06-12 19:04:10'),
(62, 33, 3, '2018-06-12 19:04:10', '2018-06-12 19:04:10'),
(63, 34, 1, '2018-06-12 19:05:43', '2018-06-12 19:05:43');

-- --------------------------------------------------------

--
-- Table structure for table `gst`
--

CREATE TABLE `gst` (
  `id` int(10) UNSIGNED NOT NULL,
  `slab_name` varchar(20) NOT NULL,
  `rate_percent` float NOT NULL,
  `is_fright_gst` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gst`
--

INSERT INTO `gst` (`id`, `slab_name`, `rate_percent`, `is_fright_gst`, `created_at`, `updated_at`) VALUES
(1, 'CGST', 14, 0, '2017-07-18 14:09:15', '2017-07-18 14:09:15'),
(2, 'SGST', 14, 0, '2017-07-18 14:09:30', '2017-07-18 14:09:30'),
(3, 'IGST', 28, 0, '2017-07-18 14:09:43', '2017-07-18 14:09:43'),
(4, 'SGSTP', 5, 1, '2017-07-18 14:21:22', '2017-07-18 14:21:22'),
(5, 'GPS_GST', 23, 1, '2018-06-12 18:35:55', '2018-06-12 18:35:55');

-- --------------------------------------------------------

--
-- Table structure for table `login_attempts`
--

CREATE TABLE `login_attempts` (
  `id` int(11) NOT NULL,
  `ip_address` varchar(40) COLLATE utf8_bin NOT NULL,
  `login` varchar(50) COLLATE utf8_bin NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `sms_bill`
--

CREATE TABLE `sms_bill` (
  `id` int(10) UNSIGNED NOT NULL,
  `party_name` varchar(100) NOT NULL,
  `bill_total` float(10,2) NOT NULL,
  `freight_charges` float NOT NULL,
  `bill_date` datetime NOT NULL,
  `is_booking` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sms_bill`
--

INSERT INTO `sms_bill` (`id`, `party_name`, `bill_total`, `freight_charges`, `bill_date`, `is_booking`, `created_at`, `updated_at`) VALUES
(1, 'Test Traders', 14789.60, 0, '2017-07-18 14:17:07', 0, '2017-07-18 14:17:07', '2017-07-18 14:17:07'),
(2, '23232', 32457.00, 3500, '2017-07-18 14:28:20', 0, '2017-07-18 14:28:20', '2017-07-18 14:28:20'),
(3, 'Ravinder bir singh ', 19410.48, 4500, '2017-07-18 14:40:09', 0, '2017-07-18 14:40:09', '2017-07-18 14:40:09'),
(4, 'GS Enterprises', 73897.00, 6500, '2017-07-18 14:53:46', 0, '2017-07-18 14:53:46', '2017-07-18 14:53:46'),
(5, 'Ters', 18313.28, 5544, '2017-10-12 00:00:00', 0, '2017-07-18 15:17:43', '2017-07-18 15:17:43'),
(6, 'Test Bill', 14425.83, 3455, '0000-00-00 00:00:00', 0, '2017-07-18 15:22:08', '2017-07-18 15:22:08'),
(7, 'GK Enter Prises', 23420.24, 3400, '2017-10-12 00:00:00', 0, '2017-07-18 15:33:57', '2017-07-18 15:33:57'),
(8, 'Tax Checker', 13911.93, 1233, '2017-07-18 00:00:00', 0, '2017-07-18 18:31:07', '2017-07-18 18:31:07'),
(9, 'Gurpreet Singh', 11331.92, 1234, '2017-07-18 00:00:00', 0, '2017-07-18 18:34:55', '2017-07-18 18:34:55'),
(10, 'Zedstart', 6219.24, 2500, '2017-09-15 00:00:00', 0, '2017-09-15 19:31:19', '2017-09-15 19:31:19'),
(11, 'Gs enterprise', 4965.30, 234, '2018-04-06 00:00:00', 0, '2018-04-03 18:35:30', '2018-04-03 18:35:30'),
(12, 'Name Not Mentioned', 3419.46, 234, '2018-05-17 00:00:00', 0, '2018-05-17 20:58:55', '2018-05-17 20:58:55'),
(13, 'Name Not Mentioned', -34.44, 123, '2018-06-10 00:00:00', 0, '2018-06-10 11:16:41', '2018-06-10 11:16:41'),
(14, 'Name Not Mentioned', 2320.00, 0, '2018-06-10 00:00:00', 0, '2018-06-10 11:17:18', '2018-06-10 11:17:18'),
(15, 'Name Not Mentioned', 45.00, 0, '2018-06-12 00:00:00', 0, '2018-06-12 18:45:11', '2018-06-12 18:45:11'),
(16, 'Gps', 254.50, 112, '2018-06-12 00:00:00', 0, '2018-06-12 18:45:33', '2018-06-12 18:45:33'),
(17, 'Test', 160.72, 34, '2018-06-12 00:00:00', 0, '2018-06-12 18:48:13', '2018-06-12 18:48:13'),
(18, 'Test', 160.72, 34, '2018-06-12 00:00:00', 0, '2018-06-12 18:48:21', '2018-06-12 18:48:21'),
(19, 'Test', 160.72, 34, '2018-06-12 00:00:00', 0, '2018-06-12 18:50:27', '2018-06-12 18:50:27'),
(20, 'Test', 384.80, 212, '2018-06-12 00:00:00', 0, '2018-06-12 18:51:26', '2018-06-12 18:51:26'),
(21, 'Test', 287.93, 113, '2018-06-13 00:00:00', 0, '2018-06-12 18:54:20', '2018-06-12 18:54:20'),
(22, 'Althea Adams', 772.00, 23, '0000-00-00 00:00:00', 0, '2018-06-12 18:54:52', '2018-06-12 18:54:52'),
(23, 'Aquila Gallegos', 688.00, 45, '0000-00-00 00:00:00', 0, '2018-06-12 18:55:12', '2018-06-12 18:55:12'),
(24, 'Genevieve Huber', 1074.70, 43, '0000-00-00 00:00:00', 0, '2018-06-12 18:57:36', '2018-06-12 18:57:36'),
(25, 'Genevieve Huber', 1074.70, 43, '0000-00-00 00:00:00', 0, '2018-06-12 18:58:00', '2018-06-12 18:58:00'),
(26, 'Jolly', 258.72, 23, '2018-06-12 00:00:00', 0, '2018-06-12 19:00:20', '2018-06-12 19:00:20'),
(27, 'Jolly', 258.72, 23, '2018-06-12 00:00:00', 0, '2018-06-12 19:02:23', '2018-06-12 19:02:23'),
(28, 'Jolly', 258.72, 23, '2018-06-12 00:00:00', 0, '2018-06-12 19:02:36', '2018-06-12 19:02:36'),
(29, 'Jolly', 258.72, 23, '2018-06-12 00:00:00', 0, '2018-06-12 19:02:46', '2018-06-12 19:02:46'),
(30, 'Jolly', 258.72, 23, '2018-06-12 00:00:00', 0, '2018-06-12 19:02:53', '2018-06-12 19:02:53'),
(31, 'Jolly', 258.72, 23, '2018-06-12 00:00:00', 0, '2018-06-12 19:03:09', '2018-06-12 19:03:09'),
(32, 'Jolly', 258.72, 23, '2018-06-12 00:00:00', 0, '2018-06-12 19:03:58', '2018-06-12 19:03:58'),
(33, 'Jolly', 258.72, 23, '2018-06-12 00:00:00', 0, '2018-06-12 19:04:10', '2018-06-12 19:04:10'),
(34, 'Risa Palmer', 1108.06, 334, '0000-00-00 00:00:00', 0, '2018-06-12 19:05:43', '2018-06-12 19:05:43');

-- --------------------------------------------------------

--
-- Table structure for table `sms_billing_items`
--

CREATE TABLE `sms_billing_items` (
  `id` int(10) UNSIGNED NOT NULL,
  `item_name` varchar(100) NOT NULL,
  `item_id` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `stock` int(11) NOT NULL,
  `bill_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sms_billing_items`
--

INSERT INTO `sms_billing_items` (`id`, `item_name`, `item_id`, `price`, `stock`, `bill_id`, `created_at`, `updated_at`) VALUES
(1, '', 7, '53.00', 0, 33, '2018-06-12 19:04:10', '2018-06-12 19:04:10'),
(2, '', 8, '113.00', 0, 33, '2018-06-12 19:04:10', '2018-06-12 19:04:10'),
(3, 'Disprin', 7, '679.00', 0, 34, '2018-06-12 19:05:43', '2018-06-12 19:05:43');

-- --------------------------------------------------------

--
-- Table structure for table `sms_category`
--

CREATE TABLE `sms_category` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(20) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sms_category`
--

INSERT INTO `sms_category` (`id`, `name`, `created_at`, `updated_at`) VALUES
(5, 'Medicines', '2018-06-09 21:38:30', '2018-06-09 21:38:30');

-- --------------------------------------------------------

--
-- Table structure for table `sms_items`
--

CREATE TABLE `sms_items` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `price_per_box` decimal(10,2) NOT NULL,
  `category_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `weight` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sms_items`
--

INSERT INTO `sms_items` (`id`, `name`, `price_per_box`, `category_id`, `created_at`, `updated_at`, `weight`) VALUES
(7, 'Disprin', '10.00', 5, '2018-06-10 11:16:06', '2018-06-10 11:16:06', '0.00'),
(8, 'Combiflame', '23.00', 5, '2018-06-12 18:08:02', '2018-06-12 18:08:02', '0.00');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) COLLATE utf8_bin NOT NULL,
  `password` varchar(255) COLLATE utf8_bin NOT NULL,
  `email` varchar(100) COLLATE utf8_bin NOT NULL,
  `role` varchar(10) COLLATE utf8_bin NOT NULL,
  `activated` tinyint(1) NOT NULL DEFAULT '1',
  `banned` tinyint(1) NOT NULL DEFAULT '0',
  `ban_reason` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `new_password_key` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `new_password_requested` datetime DEFAULT NULL,
  `new_email` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `new_email_key` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `last_ip` varchar(40) COLLATE utf8_bin NOT NULL,
  `last_login` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `role`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`) VALUES
(1, 'admin', '$2y$10$x2iFODS1cRCMXitHtswVCeOtRuCAdLwWhe28R3HE9lUIxPK3BaufG', 'gurpreet2501@gmail.com', 'admin', 1, 0, NULL, NULL, NULL, NULL, NULL, '127.0.0.1', '2018-06-12 17:56:03', '2017-05-15 00:00:00', '2018-06-12 12:26:03');

-- --------------------------------------------------------

--
-- Table structure for table `user_autologin`
--

CREATE TABLE `user_autologin` (
  `key_id` char(32) COLLATE utf8_bin NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `user_agent` varchar(150) COLLATE utf8_bin NOT NULL,
  `last_ip` varchar(40) COLLATE utf8_bin NOT NULL,
  `last_login` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `user_autologin`
--

INSERT INTO `user_autologin` (`key_id`, `user_id`, `user_agent`, `last_ip`, `last_login`) VALUES
('062b661cc4b8680716974eff10502e12', 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', '124.253.240.223', '2017-05-18 10:06:26'),
('0d28091733d55d19f4b07f5859fda37a', 1, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', '124.253.90.203', '2017-05-17 11:22:53'),
('284bde4137bb054e595ae7474d09e761', 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', '124.253.194.89', '2017-05-19 10:59:08'),
('6d3db98dc42e7d26798563ac02e9eb56', 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', '47.11.198.27', '2017-05-17 14:03:04'),
('7006b70ac3bf8b75a5c9894a6c7f7d5f', 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.47 Safari/537.36', '124.253.240.223', '2017-05-18 05:44:38'),
('76fc1da191f9da5470db44c9671539e4', 1, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', '124.253.236.145', '2017-07-23 11:19:06'),
('7b06c56d6319de2a1e22eb62d5e93bbd', 1, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', '117.200.231.130', '2017-05-17 10:56:24'),
('9ea6c7587b613fb4dcb5272f2cadfeaf', 1, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', '127.0.0.1', '2017-07-18 08:08:33'),
('aa35185479090331e262ce288cf2d34c', 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', '127.0.0.1', '2017-05-16 23:06:44'),
('b1e3b15c06144fb28cc362ebe7c6a78e', 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', '117.215.239.66', '2017-07-24 08:15:37'),
('b20b60de8252e9faf1ce72da03306e37', 1, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', '127.0.0.1', '2017-05-22 14:46:41'),
('b362a0da3fd3578bbbf461aacb20adfb', 1, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', '::1', '2017-05-17 06:41:23'),
('b3af17bf0a2756f2cdc781809abee71a', 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', '47.11.240.8', '2017-05-20 13:47:48'),
('b4abbafb29883d98faa104a73d7e2c3b', 1, 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:59.0) Gecko/20100101 Firefox/59.0', '124.253.235.130', '2018-05-17 15:28:05'),
('c01b3c73004e6d95ec4c21c1d84318ae', 1, 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0', '124.253.243.126', '2017-09-15 14:00:31'),
('c8504cea3f0f6119d9bf9c1052f289e5', 1, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36', '45.248.162.66', '2018-04-03 13:02:14'),
('ec9a6a27c827194a55f5aafab902a5a7', 1, 'Mozilla/5.0 (Linux; Android 7.1.1; ONEPLUS A3003 Build/NMF26F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.83 Mobile Safari/537.36', '47.11.242.203', '2017-05-18 12:27:25'),
('fa3300bf44cb0714a6ee0b5045161557', 1, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:60.0) Gecko/20100101 Firefox/60.0', '127.0.0.1', '2018-06-12 12:26:03');

-- --------------------------------------------------------

--
-- Table structure for table `user_profiles`
--

CREATE TABLE `user_profiles` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `country` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `website` varchar(255) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bill_gst`
--
ALTER TABLE `bill_gst`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gst`
--
ALTER TABLE `gst`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login_attempts`
--
ALTER TABLE `login_attempts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sms_bill`
--
ALTER TABLE `sms_bill`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sms_billing_items`
--
ALTER TABLE `sms_billing_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sms_category`
--
ALTER TABLE `sms_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sms_items`
--
ALTER TABLE `sms_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_autologin`
--
ALTER TABLE `user_autologin`
  ADD PRIMARY KEY (`key_id`,`user_id`);

--
-- Indexes for table `user_profiles`
--
ALTER TABLE `user_profiles`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bill_gst`
--
ALTER TABLE `bill_gst`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64;

--
-- AUTO_INCREMENT for table `gst`
--
ALTER TABLE `gst`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `login_attempts`
--
ALTER TABLE `login_attempts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sms_bill`
--
ALTER TABLE `sms_bill`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `sms_billing_items`
--
ALTER TABLE `sms_billing_items`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `sms_category`
--
ALTER TABLE `sms_category`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `sms_items`
--
ALTER TABLE `sms_items`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user_profiles`
--
ALTER TABLE `user_profiles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
